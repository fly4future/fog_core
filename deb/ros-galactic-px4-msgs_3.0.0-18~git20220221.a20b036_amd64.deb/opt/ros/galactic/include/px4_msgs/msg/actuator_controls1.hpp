// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ACTUATOR_CONTROLS1_HPP_
#define PX4_MSGS__MSG__ACTUATOR_CONTROLS1_HPP_

#include "px4_msgs/msg/detail/actuator_controls1__struct.hpp"
#include "px4_msgs/msg/detail/actuator_controls1__builder.hpp"
#include "px4_msgs/msg/detail/actuator_controls1__traits.hpp"

#endif  // PX4_MSGS__MSG__ACTUATOR_CONTROLS1_HPP_
