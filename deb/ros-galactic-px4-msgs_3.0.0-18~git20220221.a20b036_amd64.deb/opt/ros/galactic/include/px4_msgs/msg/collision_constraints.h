// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/CollisionConstraints.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__COLLISION_CONSTRAINTS_H_
#define PX4_MSGS__MSG__COLLISION_CONSTRAINTS_H_

#include "px4_msgs/msg/detail/collision_constraints__struct.h"
#include "px4_msgs/msg/detail/collision_constraints__functions.h"
#include "px4_msgs/msg/detail/collision_constraints__type_support.h"

#endif  // PX4_MSGS__MSG__COLLISION_CONSTRAINTS_H_
