// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__DEBUG_ARRAY_HPP_
#define PX4_MSGS__MSG__DEBUG_ARRAY_HPP_

#include "px4_msgs/msg/detail/debug_array__struct.hpp"
#include "px4_msgs/msg/detail/debug_array__builder.hpp"
#include "px4_msgs/msg/detail/debug_array__traits.hpp"

#endif  // PX4_MSGS__MSG__DEBUG_ARRAY_HPP_
