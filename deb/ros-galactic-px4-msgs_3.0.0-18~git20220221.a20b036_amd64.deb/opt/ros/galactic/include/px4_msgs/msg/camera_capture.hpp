// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__CAMERA_CAPTURE_HPP_
#define PX4_MSGS__MSG__CAMERA_CAPTURE_HPP_

#include "px4_msgs/msg/detail/camera_capture__struct.hpp"
#include "px4_msgs/msg/detail/camera_capture__builder.hpp"
#include "px4_msgs/msg/detail/camera_capture__traits.hpp"

#endif  // PX4_MSGS__MSG__CAMERA_CAPTURE_HPP_
