// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/ActuatorControls2.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ACTUATOR_CONTROLS2_H_
#define PX4_MSGS__MSG__ACTUATOR_CONTROLS2_H_

#include "px4_msgs/msg/detail/actuator_controls2__struct.h"
#include "px4_msgs/msg/detail/actuator_controls2__functions.h"
#include "px4_msgs/msg/detail/actuator_controls2__type_support.h"

#endif  // PX4_MSGS__MSG__ACTUATOR_CONTROLS2_H_
