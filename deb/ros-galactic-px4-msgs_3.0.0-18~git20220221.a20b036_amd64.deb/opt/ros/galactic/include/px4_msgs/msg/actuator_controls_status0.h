// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/ActuatorControlsStatus0.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ACTUATOR_CONTROLS_STATUS0_H_
#define PX4_MSGS__MSG__ACTUATOR_CONTROLS_STATUS0_H_

#include "px4_msgs/msg/detail/actuator_controls_status0__struct.h"
#include "px4_msgs/msg/detail/actuator_controls_status0__functions.h"
#include "px4_msgs/msg/detail/actuator_controls_status0__type_support.h"

#endif  // PX4_MSGS__MSG__ACTUATOR_CONTROLS_STATUS0_H_
