// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/ActuatorArmed.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ACTUATOR_ARMED_H_
#define PX4_MSGS__MSG__ACTUATOR_ARMED_H_

#include "px4_msgs/msg/detail/actuator_armed__struct.h"
#include "px4_msgs/msg/detail/actuator_armed__functions.h"
#include "px4_msgs/msg/detail/actuator_armed__type_support.h"

#endif  // PX4_MSGS__MSG__ACTUATOR_ARMED_H_
