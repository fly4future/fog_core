// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__DEBUG_VECT_HPP_
#define PX4_MSGS__MSG__DEBUG_VECT_HPP_

#include "px4_msgs/msg/detail/debug_vect__struct.hpp"
#include "px4_msgs/msg/detail/debug_vect__builder.hpp"
#include "px4_msgs/msg/detail/debug_vect__traits.hpp"

#endif  // PX4_MSGS__MSG__DEBUG_VECT_HPP_
