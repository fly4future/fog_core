// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ACTUATOR_CONTROLS_STATUS0_HPP_
#define PX4_MSGS__MSG__ACTUATOR_CONTROLS_STATUS0_HPP_

#include "px4_msgs/msg/detail/actuator_controls_status0__struct.hpp"
#include "px4_msgs/msg/detail/actuator_controls_status0__builder.hpp"
#include "px4_msgs/msg/detail/actuator_controls_status0__traits.hpp"

#endif  // PX4_MSGS__MSG__ACTUATOR_CONTROLS_STATUS0_HPP_
