// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/ActuatorControls3.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ACTUATOR_CONTROLS3_H_
#define PX4_MSGS__MSG__ACTUATOR_CONTROLS3_H_

#include "px4_msgs/msg/detail/actuator_controls3__struct.h"
#include "px4_msgs/msg/detail/actuator_controls3__functions.h"
#include "px4_msgs/msg/detail/actuator_controls3__type_support.h"

#endif  // PX4_MSGS__MSG__ACTUATOR_CONTROLS3_H_
