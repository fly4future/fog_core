// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/AdcReport.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ADC_REPORT_H_
#define PX4_MSGS__MSG__ADC_REPORT_H_

#include "px4_msgs/msg/detail/adc_report__struct.h"
#include "px4_msgs/msg/detail/adc_report__functions.h"
#include "px4_msgs/msg/detail/adc_report__type_support.h"

#endif  // PX4_MSGS__MSG__ADC_REPORT_H_
