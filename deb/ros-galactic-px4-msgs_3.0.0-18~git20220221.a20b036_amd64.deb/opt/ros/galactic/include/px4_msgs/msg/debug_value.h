// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/DebugValue.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__DEBUG_VALUE_H_
#define PX4_MSGS__MSG__DEBUG_VALUE_H_

#include "px4_msgs/msg/detail/debug_value__struct.h"
#include "px4_msgs/msg/detail/debug_value__functions.h"
#include "px4_msgs/msg/detail/debug_value__type_support.h"

#endif  // PX4_MSGS__MSG__DEBUG_VALUE_H_
