// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__ACTUATOR_CONTROLS_VIRTUAL_MC_HPP_
#define PX4_MSGS__MSG__ACTUATOR_CONTROLS_VIRTUAL_MC_HPP_

#include "px4_msgs/msg/detail/actuator_controls_virtual_mc__struct.hpp"
#include "px4_msgs/msg/detail/actuator_controls_virtual_mc__builder.hpp"
#include "px4_msgs/msg/detail/actuator_controls_virtual_mc__traits.hpp"

#endif  // PX4_MSGS__MSG__ACTUATOR_CONTROLS_VIRTUAL_MC_HPP_
