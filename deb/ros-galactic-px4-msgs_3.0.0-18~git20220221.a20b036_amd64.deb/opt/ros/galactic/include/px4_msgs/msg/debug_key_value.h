// generated from rosidl_generator_c/resource/idl.h.em
// with input from px4_msgs:msg/DebugKeyValue.idl
// generated code does not contain a copyright notice

#ifndef PX4_MSGS__MSG__DEBUG_KEY_VALUE_H_
#define PX4_MSGS__MSG__DEBUG_KEY_VALUE_H_

#include "px4_msgs/msg/detail/debug_key_value__struct.h"
#include "px4_msgs/msg/detail/debug_key_value__functions.h"
#include "px4_msgs/msg/detail/debug_key_value__type_support.h"

#endif  // PX4_MSGS__MSG__DEBUG_KEY_VALUE_H_
